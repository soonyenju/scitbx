Full name: WB_countries_Admin0_10m
Credits: World Bank